define([
	"./set-date"
], function( dateSetDate ) {

/**
 * Differently from native date.setMonth(), this function adjusts date if
 * needed, so final month is always the one set.
 *
 * setMonth( Jan31Date, 1 ): a "Feb 28" date.
 * setDate( Jan31Date, 8 ): a "Sep 30" date.
 */
return function( date, month ) {
	var originalDate = date.getDate();
	
	date.setDate( 1 );
	date.setMonth( month );
	dateSetDate( date, originalDate );
};

});
