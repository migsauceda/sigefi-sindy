datetimepicker
==============
[Documentation][doc]


jQuery Plugin Date and Time Picker

DateTimePicker

![ScreenShot](https://raw2.github.com/xdan/datetimepicker/master/screen/1.png)

DatePicker

![ScreenShot](https://raw2.github.com/xdan/datetimepicker/master/screen/2.png)

TimePicker

![ScreenShot](https://raw2.github.com/xdan/datetimepicker/master/screen/3.png)

[doc]: http://xdsoft.net/jqplugins/datetimepicker/
