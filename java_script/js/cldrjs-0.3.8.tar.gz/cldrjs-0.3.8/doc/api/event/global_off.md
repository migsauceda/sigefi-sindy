## Cldr.off( event, listener )

Removes a listener function from the specified event globally (for all instances).

| Parameter | Type | Exampe |
| --- | --- | --- |
| *event* | String | `"get"` |
| *listener* | Function | |

See [Cldr.on()](global_on.md) for example.
