## .off( event, listener )

Removes a listener function from the specified event for this instance.

| Parameter | Type | Exampe |
| --- | --- | --- |
| *event* | String | `"get"` |
| *listener* | Function | |

See [cldr.on()](on.md) for example.
