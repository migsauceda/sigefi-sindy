## .supplemental.timeData.preferred()

Helper function. Return the supplemental timeData preferred of locale's territory.

```javascript
en.supplemental.timeData.preferred();
// ➡ "h"
```
