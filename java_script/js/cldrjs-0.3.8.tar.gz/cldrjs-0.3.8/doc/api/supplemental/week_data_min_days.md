## .supplemental.weekData.minDays()

Helper function. Return the supplemental weekData minDays of locale's territory as a Number.

```javascript
en.supplemental.weekData.minDays();
// ➡ 1
```
