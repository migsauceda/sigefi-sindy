## .supplemental.weekData.firstDay()

Helper function. Return the supplemental weekData firstDay of locale's territory. 

```javascript
en.supplemental.weekData.firstDay();
// ➡ "sun"
```
