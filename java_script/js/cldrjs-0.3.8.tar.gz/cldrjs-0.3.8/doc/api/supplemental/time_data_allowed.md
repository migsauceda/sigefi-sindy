## .supplemental.timeData.allowed()

Helper function. Return the supplemental timeData allowed of locale's territory.

```javascript
en.supplemental.timeData.allowed();
// ➡ "H h"
```
