app.controller("Controlleraccesorios", function Controlleraccesorios($scope, $location, $http, $q){
    //Provesamiento de submit de login
    
   
});

/*app.service("ServicesPrincipal", function ServicesDataLogin($http, $q, $location){

});*/
